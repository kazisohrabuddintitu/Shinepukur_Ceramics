package Main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class WorkingProgress implements Serializable {
    private int empID;
    private float behaviorRating, workRating;

    public WorkingProgress(int empID, float behaviorRating, float workRating) {
        this.empID = empID;
        this.behaviorRating = behaviorRating;
        this.workRating = workRating;
    }

    public void addWorkingProgress() {
        File f = null;
        FileOutputStream fos = null;      
        ObjectOutputStream oos = null;
        
        try {
            f = new File("Working Progress.bin");
            if(f.exists()){
                fos = new FileOutputStream(f,true);
                oos = new AppendableObjectOutputStream(fos);
            }
            else{
                fos = new FileOutputStream(f);
                oos = new ObjectOutputStream(fos);               
            }
            oos.writeObject(this);

        } catch (IOException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(oos != null) oos.close();
            } catch (IOException ex) {
                Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public static ArrayList<WorkingProgress> listOfWorkingProgress(){
        ArrayList<WorkingProgress>uList = new ArrayList<>();
        
        File f = null;
        FileInputStream fis = null;      
        ObjectInputStream ois = null;
        
        try {
            f = new File("Working Progress.bin");
            fis = new FileInputStream(f);
            ois = new ObjectInputStream(fis);
           WorkingProgress u;
            try{
                while(true){
                    u = (WorkingProgress)ois.readObject();
                    uList.add(u);
                }
            }//end of nested try
            catch(Exception e){
                //
            }//nested catch                 
        } catch (IOException ex) { } 
        finally {
            try {
                if(ois != null) ois.close();
            } catch (IOException ex) { }
        }    
        return uList;
    }

    @Override
    public String toString() {
        return "Employee ID:" + empID + "\nBehavior Rating: " + behaviorRating + "\nWorkRating: " + workRating + "\n\n";
    }

    public int getEmpID() {
        return empID;
    }

    public void setEmpID(int empID) {
        this.empID = empID;
    }

    public float getBehaviorRating() {
        return behaviorRating;
    }

    public void setBehaviorRating(float behaviorRating) {
        this.behaviorRating = behaviorRating;
    }

    public float getWorkRating() {
        return workRating;
    }

    public void setWorkRating(float workRating) {
        this.workRating = workRating;
    }
    
    
}
