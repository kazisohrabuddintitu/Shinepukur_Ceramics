/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SHRODDHA
 */
public class ShowroomManager extends User implements Serializable {

    public ShowroomManager(String name, int id, String user_type, String email, String password, LocalDate BoD) {
        super(name, id, user_type, email, password, BoD);
    }

    @Override
    public void addUser() {
        File f = null;
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;

        try {
            f = new File("User.bin");
            if (f.exists()) {
                fos = new FileOutputStream(f, true);
                oos = new AppendableObjectOutputStream(fos);
            } else {
                fos = new FileOutputStream(f);
                oos = new ObjectOutputStream(fos);
            }
            oos.writeObject(this);

        } catch (IOException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (oos != null) {
                    oos.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    void createCandidate(String name, int id, String user_type, String email, String password, LocalDate BoD) {
        Salesman c = new Salesman(name, id, user_type, email, password, BoD);
        c.addUser();
    }

    void createJobList(int canID) {
        ArrayList<User> u = UserList.listOfUser();
        boolean flag = false;
        for (User i : u) {
            if (i.getId() == canID) {
                flag = true;
                Salesman c = (Salesman) i;
                c.setAddStatus(true);
                i = c;
                File f = null;
                f = new File("User.bin");
                if (f.exists()) {
                    f.delete();
                    break;
                }
            }
        }
        if (flag = true) {
            for (User j : u) {
                if (j instanceof ManagingDirector) {
                    ManagingDirector n = (ManagingDirector) j;
                    n.addUser();
                } else if (j instanceof FactoryManager) {
                    FactoryManager n = (FactoryManager) j;
                    n.addUser();
                } else if (j instanceof Supplier) {
                    Supplier n = (Supplier) j;
                    n.addUser();
                } else if (j instanceof ShowroomManager) {
                    ShowroomManager n = (ShowroomManager) j;
                    n.addUser();
                } else if (j instanceof MarketingManager) {
                    MarketingManager n = (MarketingManager) j;
                    n.addUser();
                } else if (j instanceof Salesman) {
                    Salesman n = (Salesman) j;
                    n.addUser();
                }
            }
        }
    }
}
