/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class FXMLViewMeetingScheduleByHeadController implements Initializable {

    
    
    @FXML
    private TableColumn<MeetingSchedule, String> meetingNoCol;
    @FXML
    private TableColumn<MeetingSchedule, LocalDate> dateCol;
    @FXML
    private TableColumn<MeetingSchedule, String> timeCol;
    @FXML
    private TableColumn<MeetingSchedule, String> topicCol;
    @FXML
    private TableColumn<MeetingSchedule, String> aboutCol;
    @FXML
    private TableView<MeetingSchedule> tableView;
    private ManagingDirector user;
    @FXML
    private TableColumn<MeetingSchedule, String> roomCol;
    void initData(ManagingDirector user) {
        this.user = user;
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        meetingNoCol.setCellValueFactory(new PropertyValueFactory<MeetingSchedule, String>("meetingNo"));
        dateCol.setCellValueFactory(new PropertyValueFactory<MeetingSchedule, LocalDate>("date"));
         timeCol.setCellValueFactory(new PropertyValueFactory<MeetingSchedule, String>("time"));
        topicCol.setCellValueFactory(new PropertyValueFactory<MeetingSchedule, String>("topic"));
         roomCol.setCellValueFactory(new PropertyValueFactory<MeetingSchedule, String>("meetingRoomNo"));
        aboutCol.setCellValueFactory(new PropertyValueFactory<MeetingSchedule, String>("aboutTheMeeting"));
        
        ArrayList<MeetingSchedule>mList = MeetingSchedule.listOfMeeting();
        if(mList != null){
            for(MeetingSchedule i: mList){
                if(LocalDate.now().isBefore(i.getDate())){
                    System.out.println(i.toString());
                    tableView.getItems().add(i);
                }
          
            }
        }
    }    

    @FXML
    private void onClickHomeSceneButton(ActionEvent event) throws IOException {
        FXMLLoader loader4 = new FXMLLoader();
        loader4.setLocation(getClass().getResource("FXMLHeadLoginScene.fxml"));
        Parent homeScene4 = loader4.load();
        Scene homepage4 = new Scene(homeScene4);
        FXMLHeadLoginSceneController controller4 = loader4.getController();
        controller4.initData(user);
        Stage window4 = (Stage)((Node)event.getSource()).getScene().getWindow();
        window4.setScene(homepage4);
        window4.show();
    }
    
}
