/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class FXMLApproveJobListofNewEmployeeController implements Initializable {

    @FXML
    private TableView<Candidate> tableView;
    @FXML
    private TableColumn<Candidate, String> idCol;
    @FXML
    private TableColumn<Candidate, String> nameCol;
    @FXML
    private TableColumn<Candidate, String> statusCol;

    @FXML
    private TableView<Salesman> tableView1;
    @FXML
    private TableColumn<Salesman, String> idCol1;
    @FXML
    private TableColumn<Salesman, String> nameCol1;
    @FXML
    private TableColumn<Salesman, String> statusCol1;

    private ManagingDirector md;

    public void initData(ManagingDirector h) {
        md = h;
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        idCol.setCellValueFactory(new PropertyValueFactory<Candidate, String>("id"));
        nameCol.setCellValueFactory(new PropertyValueFactory<Candidate, String>("name"));
        statusCol.setCellValueFactory(new PropertyValueFactory<Candidate, String>("status"));

        idCol1.setCellValueFactory(new PropertyValueFactory<Salesman, String>("id"));
        nameCol1.setCellValueFactory(new PropertyValueFactory<Salesman, String>("name"));
        statusCol1.setCellValueFactory(new PropertyValueFactory<Salesman, String>("status"));
        ArrayList<User> u = UserList.listOfUser();
        for (User i : u) {
            if (i instanceof Candidate) {
                Candidate c = (Candidate) i;
                if (c.isAddStatus() == true) {
                    tableView.getItems().add(c);
                }
            } else if (i instanceof Salesman) {
                Salesman c = (Salesman) i;
                if (c.isAddStatus() == true) {
                    tableView1.getItems().add(c);
                }
            }
        }

        tableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        tableView1.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }

    @FXML
    private void onClickHomeSceneButton(ActionEvent event) throws IOException {
        FXMLLoader loader4 = new FXMLLoader();
        loader4.setLocation(getClass().getResource("FXMLHeadLoginScene.fxml"));
        Parent homeScene4 = loader4.load();
        Scene homepage4 = new Scene(homeScene4);
        FXMLHeadLoginSceneController controller4 = loader4.getController();
        controller4.initData(md);
        Stage window4 = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window4.setScene(homepage4);
        window4.show();
    }

    @FXML
    private void onClickDisappove1Button(ActionEvent event) throws IOException {
        ObservableList<Candidate> selectedRows;

        selectedRows = tableView.getSelectionModel().getSelectedItems();

        for (Candidate p : selectedRows) {
            md.approveCandidateJobList(p, false);
        }

        FXMLLoader loader1 = new FXMLLoader();
        loader1.setLocation(getClass().getResource("FXMLApproveJobListofNewEmployee.fxml"));
        Parent homeScene1 = loader1.load();
        Scene homepage1 = new Scene(homeScene1);
        FXMLApproveJobListofNewEmployeeController controller1 = loader1.getController();
        controller1.initData(md);
        Stage window1 = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window1.setScene(homepage1);
        window1.show();
    }

    @FXML
    private void onClickApprove2Button(ActionEvent event) throws IOException {

        ObservableList<Salesman> selectedRows1;

        selectedRows1 = tableView1.getSelectionModel().getSelectedItems();

        for (Salesman s : selectedRows1) {
            md.approveCandidateJobList(s, true);
        }

        FXMLLoader loader1 = new FXMLLoader();
        loader1.setLocation(getClass().getResource("FXMLApproveJobListofNewEmployee.fxml"));
        Parent homeScene1 = loader1.load();
        Scene homepage1 = new Scene(homeScene1);
        FXMLApproveJobListofNewEmployeeController controller1 = loader1.getController();
        controller1.initData(md);
        Stage window1 = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window1.setScene(homepage1);
        window1.show();
    }

    @FXML
    private void onClickApprove1Button(ActionEvent event) throws IOException {
        ObservableList<Candidate> selectedRows;

        selectedRows = tableView.getSelectionModel().getSelectedItems();
        ;
        for (Candidate p : selectedRows) {
            md.approveCandidateJobList(p, true);
        }

        FXMLLoader loader1 = new FXMLLoader();
        loader1.setLocation(getClass().getResource("FXMLApproveJobListofNewEmployee.fxml"));
        Parent homeScene1 = loader1.load();
        Scene homepage1 = new Scene(homeScene1);
        FXMLApproveJobListofNewEmployeeController controller1 = loader1.getController();
        controller1.initData(md);
        Stage window1 = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window1.setScene(homepage1);
        window1.show();
    }

    @FXML
    private void onClickDisappove2Button(ActionEvent event) throws IOException {

        ObservableList<Salesman> selectedRows1;

        selectedRows1 = tableView1.getSelectionModel().getSelectedItems();

        for (Salesman s : selectedRows1) {
            md.approveCandidateJobList(s, false);
        }
        FXMLLoader loader1 = new FXMLLoader();
        loader1.setLocation(getClass().getResource("FXMLApproveJobListofNewEmployee.fxml"));
        Parent homeScene1 = loader1.load();
        Scene homepage1 = new Scene(homeScene1);
        FXMLApproveJobListofNewEmployeeController controller1 = loader1.getController();
        controller1.initData(md);
        Stage window1 = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window1.setScene(homepage1);
        window1.show();
    }

}
