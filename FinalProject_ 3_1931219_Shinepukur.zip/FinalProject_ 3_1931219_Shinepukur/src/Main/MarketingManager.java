/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SHRODDHA
 */
public class MarketingManager extends User implements Serializable{

    public MarketingManager(String name, int id, String user_type, String email, String password, LocalDate BoD) {
        super(name, id, user_type, email, password, BoD);
    }

    @Override
    public void addUser() {
        File f = null;
        FileOutputStream fos = null;      
        ObjectOutputStream oos = null;
        
        try {
            f = new File("User.bin");
            if(f.exists()){
                fos = new FileOutputStream(f,true);
                oos = new AppendableObjectOutputStream(fos);
            }
            else{
                fos = new FileOutputStream(f);
                oos = new ObjectOutputStream(fos);               
            }
            oos.writeObject(this);

        } catch (IOException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(oos != null) oos.close();
            } catch (IOException ex) {
                Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    void createMeetingSchedule(LocalDate date, String time, String topic, String meetingRoomNo, String aboutTheMeeting, int meetingNo) {
        MeetingSchedule m = new MeetingSchedule(date, time, topic, meetingRoomNo, aboutTheMeeting, meetingNo);
        m.addMeetingSchedule();
    }
    
    public String viewMeetingSchedule(){
        ArrayList<MeetingSchedule> m = new ArrayList<>();
        m = MeetingSchedule.listOfMeeting();
        String st = "";
        if (m != null) {
            for (MeetingSchedule i : m) {
                st = st+(i.toString());
            }
        }
        return st;
    }

    void createProductionTarget(String productName, int dailyTarget, int yearly, int monthly, int weekly) {
        ProductionTarget p = new ProductionTarget(productName, dailyTarget, yearly, monthly, weekly);
        p.addProductTarget();
    }
    
}
