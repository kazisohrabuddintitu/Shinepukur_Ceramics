/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class FXMLViewandSendMessageController implements Initializable {

    @FXML
    private TextArea inboxField;
    @FXML
    private TextArea msgBodyField;
    @FXML
    private TextField from;
    @FXML
    private TextField to;
    @FXML
    private TextField subjectField;
    @FXML
    private DatePicker date;
    
    
    private User u;
    public void initData(User user){
        u = user;
        from.setText(Integer.toString(this.u.getId()));
        
        ArrayList<Message>uList = Message.listOfMessage();
        for(Message m: uList){
            if(m.getToID() == this.u.getId()){
                inboxField.appendText(m.toString());
            }
        }
        date.setValue(LocalDate.now());
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void onClickHomeSceneButton(ActionEvent event) throws IOException {
            if(u instanceof ManagingDirector){
                FXMLLoader loader1 = new FXMLLoader();
                loader1.setLocation(getClass().getResource("FXMLHeadLoginScene.fxml"));
                Parent homeScene1 = loader1.load();
                Scene homepage1 = new Scene(homeScene1);
                FXMLHeadLoginSceneController controller1 = loader1.getController();
                controller1.initData((ManagingDirector)u);
                Stage window1 = (Stage)((Node)event.getSource()).getScene().getWindow();
                window1.setScene(homepage1);
                window1.show();
            }
            else if(u instanceof FactoryManager){
                FXMLLoader loader2 = new FXMLLoader();
                loader2.setLocation(getClass().getResource("FXMLFactoryManager.fxml"));
                Parent homeScene2 = loader2.load();
                Scene homepage2 = new Scene(homeScene2);
                FXMLFactoryManagerController controller2 = loader2.getController();
                controller2.initData((FactoryManager)u);
                Stage window2 = (Stage)((Node)event.getSource()).getScene().getWindow();
                window2.setScene(homepage2);
                window2.show();
            }
            else if(u instanceof MarketingManager){
                FXMLLoader loader3 = new FXMLLoader();
                loader3.setLocation(getClass().getResource("FXMLMarketingManager.fxml"));
                Parent homeScene3 = loader3.load();
                Scene homepage3 = new Scene(homeScene3);
                FXMLMarketingManagerController controller3 = loader3.getController();
                controller3.initData((MarketingManager)u);
                Stage window3 = (Stage)((Node)event.getSource()).getScene().getWindow();
                window3.setScene(homepage3);
                window3.show();
            }
            else if(u instanceof ShowroomManager){
                FXMLLoader loader4 = new FXMLLoader();
                loader4.setLocation(getClass().getResource("FXMLShowroomManager.fxml"));
                Parent homeScene4 = loader4.load();
                Scene homepage4 = new Scene(homeScene4);
                FXMLShowroomManagerController controller4 = loader4.getController();
                controller4.initData((ShowroomManager)u);
                Stage window4 = (Stage)((Node)event.getSource()).getScene().getWindow();
                window4.setScene(homepage4);
                window4.show();
            }
            else if(u instanceof Supplier){
                FXMLLoader loader5 = new FXMLLoader();
                loader5.setLocation(getClass().getResource("FXMLSupplier.fxml"));
                Parent homeScene5 = loader5.load();
                Scene homepage5 = new Scene(homeScene5);
                FXMLSupplierController controller5 = loader5.getController();
                controller5.initData((Supplier)u);
                Stage window5 = (Stage)((Node)event.getSource()).getScene().getWindow();
                window5.setScene(homepage5);
                window5.show();
            }  
    }

    @FXML
    private void onClickSendButton(ActionEvent event) {
        Message m = new Message(
                Integer.parseInt(to.getText()),
                Integer.parseInt(from.getText()),
                date.getValue(),
                msgBodyField.getText(),
                subjectField.getText()
        );
        m.addMessage();
        to.setText(null);
        msgBodyField.setText(null);
        subjectField.setText(null);
    }
    
}
