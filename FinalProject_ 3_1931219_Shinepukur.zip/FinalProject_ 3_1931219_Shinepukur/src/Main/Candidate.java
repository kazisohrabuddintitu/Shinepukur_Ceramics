package Main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Candidate extends User implements Serializable{
    private boolean addStatus,status;

    public Candidate(String name, int id, String user_type, String email, String password, LocalDate BoD) {
        super(name, id, user_type, email, password, BoD);
        addStatus = false;
    }
    public static ArrayList<Candidate> listOfCandidate(){
        ArrayList<Candidate>uList = new ArrayList<>();
        
        File f = null;
        FileInputStream fis = null;      
        ObjectInputStream ois = null;
        
        try {
            f = new File("User.bin");
            fis = new FileInputStream(f);
            ois = new ObjectInputStream(fis);
            User u;
            try{
                while(true){
                    u = (User)ois.readObject();
                    if(u instanceof Candidate){
                        uList.add((Candidate)u);
                    }
                }
            }//end of nested try
            catch(Exception e){
                //
            }//nested catch                 
        } catch (IOException ex) { } 
        finally {
            try {
                if(ois != null) ois.close();
            } catch (IOException ex) { }
        }    
        return uList;
    
    }
    
    @Override
    public void addUser() {
        File f = null;
        FileOutputStream fos = null;      
        ObjectOutputStream oos = null;
        
        try {
            f = new File("User.bin");
            if(f.exists()){
                fos = new FileOutputStream(f,true);
                oos = new AppendableObjectOutputStream(fos);
            }
            else{
                fos = new FileOutputStream(f);
                oos = new ObjectOutputStream(fos);               
            }
            oos.writeObject(this);

        } catch (IOException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(oos != null) oos.close();
            } catch (IOException ex) {
                Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    @Override
    public String toString() {
        return "Name: " + name +  "\nID: " + id + "\nUser type: " + user_type + "\nPassword=" + password 
                + "\nEmail: " + email + "\nBirth of Date: " + BoD + "\n" + "Working Hour: " +"\nStatus: "+ status + "\n\n";
    }

    public boolean isStatus() {
        return status;
    }

    public String getName() {
        return name;
    }

    public String getUser_type() {
        return user_type;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public LocalDate getBoD() {
        return BoD;
    }

    public int getId() {
        return id;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public void setAddStatus(boolean addStatus) {
        this.addStatus = addStatus;
    }

    public boolean isAddStatus() {
        return addStatus;
    }
    
}
