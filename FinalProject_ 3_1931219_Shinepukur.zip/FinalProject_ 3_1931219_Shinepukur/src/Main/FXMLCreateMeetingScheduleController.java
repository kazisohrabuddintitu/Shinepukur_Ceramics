/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class FXMLCreateMeetingScheduleController implements Initializable {

    @FXML
    private TextField meetingNo;
    @FXML
    private TextField meetingTime;
    @FXML
    private DatePicker meetingDate;
    @FXML
    private TextField roomNumber;
    @FXML
    private TextField topic;
    @FXML
    private TextArea about;
    @FXML
    private TextArea viewField;

    /**
     * Initializes the controller class.
     */
    private MarketingManager user;

    void initData(MarketingManager user) {
        this.user = user;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        Random rand = new Random();
        int rand_int1 = rand.nextInt(1000);
        meetingNo.setText(Integer.toString(rand_int1));
    }

    @FXML
    private void clickOnSubmitButton(ActionEvent event) {
        Random rand = new Random();
        int rand_int1 = rand.nextInt(1000);
        
        user.createMeetingSchedule(
                meetingDate.getValue(),
                meetingTime.getText(),
                topic.getText(),
                roomNumber.getText(),
                about.getText(),
                Integer.parseInt(meetingNo.getText())
        );
        meetingDate.setValue(null);
        meetingTime.setText(null);
        topic.setText(null);
        roomNumber.setText(null);
        about.setText(null);
        meetingNo.setText(Integer.toString(rand_int1));
    }

    @FXML
    private void clickOnViewMeetingButton(ActionEvent event) {
        viewField.setText(user.viewMeetingSchedule());
        viewField.appendText("Completed!!!");
    }

    @FXML
    private void onClickHomeSceneButton(ActionEvent event) throws IOException {

        FXMLLoader loader1 = new FXMLLoader();
        loader1.setLocation(getClass().getResource("FXMLMarketingManager.fxml"));
        Parent homeScene1 = loader1.load();
        Scene homepage1 = new Scene(homeScene1);
        FXMLMarketingManagerController controller1 = loader1.getController();
        controller1.initData(user);
        Stage window1 = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window1.setScene(homepage1);
        window1.show();
    }

}
