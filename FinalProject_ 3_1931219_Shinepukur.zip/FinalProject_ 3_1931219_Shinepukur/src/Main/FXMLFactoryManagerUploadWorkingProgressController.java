/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author SHRODDHA
 */
public class FXMLFactoryManagerUploadWorkingProgressController implements Initializable {
    private FactoryManager user;

    public void initData(FactoryManager h) {
        user = h;
    }
    @FXML
    private TextField id;
    @FXML
    private ComboBox<String> behaviorCombo;
    @FXML
    private ComboBox<String> workCombo;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        behaviorCombo.getItems().addAll("1","2","3","4","5");
        workCombo.getItems().addAll("1","2","3","4","5");
    }    

    @FXML
    private void onClickAddEmployeeButton(ActionEvent event) {
        user.updateWorkingProgress(
           Integer.parseInt(id.getText()),
           Float.parseFloat(behaviorCombo.getValue()),
           Float.parseFloat(workCombo.getValue())
        );
        id.setText(null);
        behaviorCombo.setValue(null);
        workCombo.setValue(null);
    }

    @FXML
    private void clickOnHomeScreenButton(ActionEvent event) throws IOException {
        FXMLLoader loader2 = new FXMLLoader();
                loader2.setLocation(getClass().getResource("FXMLFactoryManager.fxml"));
                Parent homeScene2 = loader2.load();
                Scene homepage2 = new Scene(homeScene2);
                FXMLFactoryManagerController controller2 = loader2.getController();
                controller2.initData(user);
                Stage window2 = (Stage)((Node)event.getSource()).getScene().getWindow();
                window2.setScene(homepage2);
                window2.show();
    }
    
}
