/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class FXMLUploadProductionTargetByMarketingManagerController implements Initializable {

    @FXML
    private TextField nameField;
    @FXML
    private TextField dailyTargetField;
    @FXML
    private TextField weeklyTargetField;
    @FXML
    private TextField monthlyTargetField;
    @FXML
    private TextField yearlyTargetField;
    
     private MarketingManager user;
    
    public void initData(MarketingManager h){
        user = h;
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void OnCLickBackButton(ActionEvent event) throws IOException {
        FXMLLoader loader3 = new FXMLLoader();
                loader3.setLocation(getClass().getResource("FXMLMarketingManager.fxml"));
                Parent homeScene3 = loader3.load();
                Scene homepage3 = new Scene(homeScene3);
                FXMLMarketingManagerController controller3 = loader3.getController();
                controller3.initData(user);
                Stage window3 = (Stage)((Node)event.getSource()).getScene().getWindow();
                window3.setScene(homepage3);
                window3.show();
    }

    @FXML
    private void OnCLickSaveButton(ActionEvent event) {
        user.createProductionTarget(
              nameField.getText(),
              Integer.parseInt(dailyTargetField.getText()),
              Integer.parseInt(yearlyTargetField.getText()),
              Integer.parseInt(monthlyTargetField.getText()),
              Integer.parseInt(weeklyTargetField.getText())
        );
        nameField.setText(null);
        dailyTargetField.setText(null);
        yearlyTargetField.setText(null);
        weeklyTargetField.setText(null);
        monthlyTargetField.setText(null);
    }
    
}
