/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author user
 */
public class FXMLCreateNewCandidateShortListByFactoryManagerController implements Initializable {

    @FXML
    private TableView<Candidate> tableView;
    @FXML
    private TableColumn<Candidate, String> idCol;
    @FXML
    private TableColumn<Candidate, String> nameCol;
    @FXML
    private TextField candID;
    
    private FactoryManager user;
    void initData(FactoryManager user) {
        this.user = user;
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        idCol.setCellValueFactory(new PropertyValueFactory<Candidate,String>("id"));
        nameCol.setCellValueFactory(new PropertyValueFactory<Candidate,String>("name"));
        
        ArrayList<User>u = UserList.listOfUser();
        if(u != null){
            for(User i: u){
                if(i instanceof Candidate){
                    Candidate c = (Candidate)i;
                    if(c.isAddStatus()==false)    
                        tableView.getItems().add(c);
                }
            }
        }
    }    

    @FXML
    private void onClickAddCandidate(ActionEvent event) {
        int canID = Integer.parseInt(candID.getText());
        user.createJobList(canID);
        candID.setText(null);
    }

    @FXML
    private void onCLickOnHomeScene(ActionEvent event) throws IOException {
        FXMLLoader loader2 = new FXMLLoader();
                loader2.setLocation(getClass().getResource("FXMLFactoryManager.fxml"));
                Parent homeScene2 = loader2.load();
                Scene homepage2 = new Scene(homeScene2);
                FXMLFactoryManagerController controller2 = loader2.getController();
                controller2.initData(user);
                Stage window2 = (Stage)((Node)event.getSource()).getScene().getWindow();
                window2.setScene(homepage2);
                window2.show();
    }
    
}
