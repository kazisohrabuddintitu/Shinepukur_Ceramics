package Main;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ManagingDirector extends User implements Serializable {

    public ManagingDirector(String name, int id, String user_type, String email, String password, LocalDate BoD) {
        super(name, id, user_type, email, password, BoD);
    }

    @Override
    public void addUser() {
        File f = null;
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;

        try {
            f = new File("User.bin");
            if (f.exists()) {
                fos = new FileOutputStream(f, true);
                oos = new AppendableObjectOutputStream(fos);
            } else {
                fos = new FileOutputStream(f);
                oos = new ObjectOutputStream(fos);
            }
            oos.writeObject(this);

        } catch (IOException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (oos != null) {
                    oos.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    void approvePromotionList(PromotionList p, boolean b) {
        ArrayList<PromotionList> pList = PromotionList.getPromotionList();
        File f = null;
        f = new File("Promotion List.bin");
        if (f.exists()) {
            f.delete();
        }
        for (PromotionList i : pList) {
            if (i.getEmpID() == p.getEmpID()) {
                i.setStatus(b);
            }
            i.addPromotionList();
        }

    }

    public static void createUser(String name, int id, String user_type, String email, String password, LocalDate BoD) {
        if (user_type == "Managing Director") {
            ManagingDirector h = new ManagingDirector(
                    name, id, user_type, email, password, BoD
            );
            h.addUser();
        } else if (user_type == "Showroom Manager") {
            ShowroomManager h = new ShowroomManager(
                    name, id, user_type, email, password, BoD
            );
            h.addUser();
        } else if (user_type == "Factory Manager") {
            FactoryManager h = new FactoryManager(
                    name, id, user_type, email, password, BoD
            );
            h.addUser();
        } else if (user_type == "Marketing Manager") {
            MarketingManager h = new MarketingManager(
                    name, id, user_type, email, password, BoD
            );
            h.addUser();
        } else if (user_type == "Supplier") {
            Supplier h = new Supplier(
                    name, id, user_type, email, password, BoD
            );
            h.addUser();
        }
    }

    void approveCandidateJobList(Candidate p, boolean b) {

        ArrayList<User> pList = UserList.listOfUser();
        File f = null;
        f = new File("User.bin");
        if (f.exists()) {
            f.delete();
        }
        for (User i : pList) {
            if (i.getId() == p.getId()) {
                Candidate u = (Candidate) i;

                u.setStatus(b);
                u.addUser();
            } else {
                i.addUser();
            }

        }
    }

    void approveCandidateJobList(Salesman p, boolean b) {

        ArrayList<User> pList = UserList.listOfUser();
        File f = null;
        f = new File("User.bin");
        if (f.exists()) {
            f.delete();
        }
        for (User i : pList) {

            if (i.getId() == p.getId()) {
                Salesman u = (Salesman) i;

                u.setStatus(b);
                u.addUser();
            } else {
                i.addUser();
            }

        }
    }
}
