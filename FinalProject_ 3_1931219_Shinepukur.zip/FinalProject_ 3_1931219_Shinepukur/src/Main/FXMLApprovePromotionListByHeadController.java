/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class FXMLApprovePromotionListByHeadController implements Initializable {

    
        
    @FXML
    private TableView<PromotionList> tableView;
    @FXML
    private TableColumn<PromotionList, String> idCol;
    @FXML
    private TableColumn<PromotionList, String> postCol;
    @FXML
    private TableColumn<PromotionList, String> reasonCol;
    @FXML
    private TableColumn<PromotionList, String> nameCol;
    @FXML
    private TableColumn<PromotionList, String> statusCol;
    
    private ManagingDirector md;
    
    public void initData(ManagingDirector h){
        md = h;
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        idCol.setCellValueFactory(new PropertyValueFactory<PromotionList,String>("empID"));
        postCol.setCellValueFactory(new PropertyValueFactory<PromotionList,String>("suggestedPost"));
        reasonCol.setCellValueFactory(new PropertyValueFactory<PromotionList,String>("reasonOfPromotion"));
        nameCol.setCellValueFactory(new PropertyValueFactory<PromotionList,String>("empName"));
        statusCol.setCellValueFactory(new PropertyValueFactory<PromotionList,String>("status"));
        
        ArrayList<PromotionList>pList = PromotionList.getPromotionList();
        for(PromotionList i: pList){
            System.out.println(i.toString());
            tableView.getItems().add(i);
        }
        
        tableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE); 
    }    

    @FXML
    private void onClickDisapproveButton(ActionEvent event) throws IOException {
        ObservableList<PromotionList> selectedRows;
        selectedRows = tableView.getSelectionModel().getSelectedItems();
        
        for(PromotionList p: selectedRows){
            md.approvePromotionList(p, false);
        }
        FXMLLoader loader4 = new FXMLLoader();
        loader4.setLocation(getClass().getResource("FXMLApprovePromotionListByHead.fxml"));
        Parent homeScene4 = loader4.load();
        Scene homepage4 = new Scene(homeScene4);
        FXMLApprovePromotionListByHeadController controller4 = loader4.getController();
        controller4.initData(md);
        Stage window4 = (Stage)((Node)event.getSource()).getScene().getWindow();
        window4.setScene(homepage4);
        window4.show();
    }

    @FXML
    private void onClickApproveButton(ActionEvent event) throws IOException {
        ObservableList<PromotionList> selectedRows;
        selectedRows = tableView.getSelectionModel().getSelectedItems();
        
        for(PromotionList p: selectedRows){
            md.approvePromotionList(p, true);
        }
        FXMLLoader loader4 = new FXMLLoader();
        loader4.setLocation(getClass().getResource("FXMLApprovePromotionListByHead.fxml"));
        Parent homeScene4 = loader4.load();
        Scene homepage4 = new Scene(homeScene4);
        FXMLApprovePromotionListByHeadController controller4 = loader4.getController();
        controller4.initData(md);
        Stage window4 = (Stage)((Node)event.getSource()).getScene().getWindow();
        window4.setScene(homepage4);
        window4.show();
    }

    @FXML
    private void onClickHomeSceneButton(ActionEvent event) throws IOException {
        FXMLLoader loader4 = new FXMLLoader();
        loader4.setLocation(getClass().getResource("FXMLHeadLoginScene.fxml"));
        Parent homeScene4 = loader4.load();
        Scene homepage4 = new Scene(homeScene4);
        FXMLHeadLoginSceneController controller4 = loader4.getController();
        controller4.initData(md);
        Stage window4 = (Stage)((Node)event.getSource()).getScene().getWindow();
        window4.setScene(homepage4);
        window4.show();
    }

    
}
